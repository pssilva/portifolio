<?php
/**
 * GroupFixture
 *
 */
class GroupFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'key' => 'primary', 'comment' => 'ID'),
		'uuid' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 36, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'g_nome' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 120, 'collate' => 'utf8_general_ci', 'comment' => 'Grupo', 'charset' => 'utf8'),
		'g_descricao' => array('type' => 'string', 'null' => true, 'default' => null, 'collate' => 'utf8_general_ci', 'comment' => 'Descrição', 'charset' => 'utf8'),
		'modifiedUserById' => array('type' => 'integer', 'null' => false, 'default' => '-1', 'length' => 10, 'comment' => 'Modificado por'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => null, 'comment' => 'Criado em'),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => null, 'comment' => 'Modificado em'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'uuid' => 'Lorem ipsum dolor sit amet',
			'g_nome' => 'Lorem ipsum dolor sit amet',
			'g_descricao' => 'Lorem ipsum dolor sit amet',
			'modifiedUserById' => 1,
			'created' => '2014-06-04 16:02:14',
			'modified' => '2014-06-04 16:02:14'
		),
	);

}
