<?php
/**
 * UserFixture
 *
 */
class UserFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'length' => 10, 'key' => 'primary', 'comment' => 'ID'),
		'uuid' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 36, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'group_id' => array('type' => 'integer', 'null' => false, 'default' => '-1', 'length' => 10, 'key' => 'index', 'comment' => 'Regra'),
		'username' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 50, 'collate' => 'utf8_general_ci', 'comment' => 'Login', 'charset' => 'utf8'),
		'password' => array('type' => 'string', 'null' => true, 'default' => null, 'length' => 50, 'collate' => 'utf8_general_ci', 'comment' => 'Senha', 'charset' => 'utf8'),
		'userId' => array('type' => 'integer', 'null' => false, 'default' => '-1', 'length' => 10, 'comment' => 'Usuário que cadastrou ou alterou'),
		'modifiedByUserId' => array('type' => 'integer', 'null' => false, 'default' => '-1', 'length' => 10, 'comment' => 'Modificado por'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => null, 'comment' => 'Criado em'),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => null, 'comment' => 'Modificado em'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1),
			'fk_users_1_idx' => array('column' => 'group_id', 'unique' => 0)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'uuid' => 'Lorem ipsum dolor sit amet',
			'group_id' => 1,
			'username' => 'Lorem ipsum dolor sit amet',
			'password' => 'Lorem ipsum dolor sit amet',
			'userId' => 1,
			'modifiedByUserId' => 1,
			'created' => '2014-06-04 16:01:41',
			'modified' => '2014-06-04 16:01:41'
		),
	);

}
