<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
    public $components = array(
		'Session',
//                'Auth' => array(
//                    'loginRedirect' => array('controller' => 'projetos', 'action' => 'index'),
//                    'logoutRedirect' => array('controller' => 'pages', 'action' => 'display', 'home')),
         'Auth' => array(
                    'authenticate' => array(
                                            'Form' => array( 'userModel' => 'User',
                                            'fields' => array(
                                                        'username' => 'username',
                                                        'password' => 'password'
                                                        )
                                                )
                                            ),
                    'loginRedirect' => array('controller' => 'projetos', 'action' => 'index'),
                    'logoutRedirect' => array('controller' => 'pages', 'action' => 'index'),
                    //'authorize' => array('Controller') // Added this line
                 ),
		//'Security',
                'Acl'
        );
    
     function beforeFilter() {
         parent::beforeFilter();
         
          Security::setHash('md5'); // Setamos o algoritmo que iremos utilizar, o padrão é sha1 mudei para md5
          $this->Auth->allow();
          //$this->Auth->authorize = 'actions';
         //$this->Auth->allow('index','login','logout', 'home');
    }
    
    
    
    
//  public function beforeFilter() {
//        if(in_array($this->params['controller'],array('rest_users'))){
//            // For RESTful web service requests, we check the name of our contoller
//            $this->Auth->allow();
//            // this line should always be there to ensure that all rest calls are secure
//            /* $this->Security->requireSecure(); */
//            $this->Security->unlockedActions = array('edit','delete','add','view');
//        }else{
//            // setup out Auth
//            $this->Auth->allow();			
//        }
//    }
    
}
