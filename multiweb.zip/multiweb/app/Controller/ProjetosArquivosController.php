<?php
App::uses('AppController', 'Controller');
/**
 * ProjetosArquivos Controller
 *
 * @property ProjetosArquivo $ProjetosArquivo
 * @property PaginatorComponent $Paginator
 */
class ProjetosArquivosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->ProjetosArquivo->recursive = 0;
		$this->set('projetosArquivos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->ProjetosArquivo->exists($id)) {
			throw new NotFoundException(__('Invalid projetos arquivo'));
		}
		$options = array('conditions' => array('ProjetosArquivo.' . $this->ProjetosArquivo->primaryKey => $id));
		$this->set('projetosArquivo', $this->ProjetosArquivo->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->ProjetosArquivo->create();
			if ($this->ProjetosArquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The projetos arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The projetos arquivo could not be saved. Please, try again.'));
			}
		}
		$projetos = $this->ProjetosArquivo->Projeto->find('list');
		$arquivos = $this->ProjetosArquivo->Arquivo->find('list');
		$this->set(compact('projetos', 'arquivos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->ProjetosArquivo->exists($id)) {
			throw new NotFoundException(__('Invalid projetos arquivo'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->ProjetosArquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The projetos arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The projetos arquivo could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('ProjetosArquivo.' . $this->ProjetosArquivo->primaryKey => $id));
			$this->request->data = $this->ProjetosArquivo->find('first', $options);
		}
		$projetos = $this->ProjetosArquivo->Projeto->find('list');
		$arquivos = $this->ProjetosArquivo->Arquivo->find('list');
		$this->set(compact('projetos', 'arquivos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->ProjetosArquivo->id = $id;
		if (!$this->ProjetosArquivo->exists()) {
			throw new NotFoundException(__('Invalid projetos arquivo'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->ProjetosArquivo->delete()) {
			$this->Session->setFlash(__('The projetos arquivo has been deleted.'));
		} else {
			$this->Session->setFlash(__('The projetos arquivo could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
        
    public function salvar($idArquivo,$idProjeto){
        
        if(!empty($idProjeto) && !empty($idArquivo))
        {    
            $projetosArquivo = array();
            $uuid = $this->generateUuid();
            $projetosArquivo['uuid'] = $uuid['uuid'];
            $projetosArquivo['projeto_id'] = $idProjeto;
            $projetosArquivo['arquivo_id'] =  $idArquivo;
            $projetosArquivo['userId'] = "-1";
            $projetosArquivo['modifiedByUserId'] = "-1";
            
            $this->ProjetosArquivo->create();
            
            if($this->ProjetosArquivo->save($projetosArquivo))
            {
                return $this->ProjetosArquivo->id;
            }
            else{
                return 0;
            }
        }
        return 0;
    }        
}
