<?php
App::uses('AppController', 'Controller');
/**
 * Projetos Controller
 *
 * @property Projeto $Projeto
 * @property PaginatorComponent $Paginator
 */
class ProjetosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
            $this->layout = 'cpanel';
		$this->Projeto->recursive = 0;
		$this->set('projetos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
            $this->layout = 'cpanel';
		if (!$this->Projeto->exists($id)) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		$options = array('conditions' => array('Projeto.' . $this->Projeto->primaryKey => $id));
		$this->set('projeto', $this->Projeto->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
            $this->layout = 'cpanel';
		if ($this->request->is('post')) {
			$this->Projeto->create();
			if ($this->Projeto->save($this->request->data)) {
				$this->Session->setFlash(__('The projeto has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The projeto could not be saved. Please, try again.'));
			}
		}
		$arquivos = $this->Projeto->Arquivo->find('list');
		$this->set(compact('arquivos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
            $this->layout = 'cpanel';
		if (!$this->Projeto->exists($id)) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Projeto->save($this->request->data)) {
				$this->Session->setFlash(__('The projeto has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The projeto could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Projeto.' . $this->Projeto->primaryKey => $id));
			$this->request->data = $this->Projeto->find('first', $options);
		}
		$arquivos = $this->Projeto->Arquivo->find('list');
		$this->set(compact('arquivos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
            $this->layout = 'cpanel';   
		$this->Projeto->id = $id;
		if (!$this->Projeto->exists()) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->Projeto->delete()) {
			$this->Session->setFlash(__('The projeto has been deleted.'));
		} else {
			$this->Session->setFlash(__('The projeto could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}}
