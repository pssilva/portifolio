<?php
App::uses('AppController', 'Controller');
App::import('Controller','Arquivos');
/**
 * Projetos Controller
 *
 * @property Projeto $Projeto
 * @property PaginatorComponent $Paginator
 */
class ProjetosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
            $this->layout = 'cpanel';
		$this->Projeto->recursive = 0;
		$this->set('projetos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
            $this->layout = 'cpanel';
		if (!$this->Projeto->exists($id)) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		$options = array('conditions' => array('Projeto.' . $this->Projeto->primaryKey => $id));
		$this->set('projeto', $this->Projeto->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
            $this->layout = 'cpanel';
            
		if ($this->request->is('post')) {
                    $projeto = array();
                    $projeto['Projeto'] = $this->request->data['Projeto'];
                    
                    $projeto['Projeto']['dt_inicio'] = date("Y-m-d",strtotime($projeto['Projeto']['dt_inicio']));
                    $projeto['Projeto']['dt_fim'] = date("Y-m-d",strtotime($projeto['Projeto']['dt_fim']));
                    $projeto['Projeto']['userId'] = ($projeto['Projeto']['userId']==null || $projeto['Projeto']['userId']=='')?"-1":$projeto['Projeto']['userId'];
                    
			$this->Projeto->create();
			if ($this->Projeto->save($projeto['Projeto'])) {
                            $projeto = $this->getProjetoById($this->Projeto->id);
                            $this->createPath(WWW_ROOT . DS . 'files' . DS . 'projetos' . DS . $projeto['Projeto']['uuid']);
                            
                           $arquivosController = new ArquivosController();
                           $arquivosController->salvarArquivos($this->request->data['Arquivo'],$projeto);
                            
                           $this->Session->setFlash(__('Projeto salvo com sucesso!.'));    
                           return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('O projeto não pode ser salvo. Por favor, tente novamente.'));
			}
		}
		$arquivos = $this->Projeto->Arquivo->find('list');
		$this->set(compact('arquivos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
            $this->layout = 'cpanel';            
            
		if (!$this->Projeto->exists($id)) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		if ($this->request->is(array('post', 'put'))) {
                    $projeto = array();
                    $projeto['Projeto'] = $this->request->data['Projeto'];
                    
                    $projeto['Projeto']['dt_inicio'] = date('Y-m-d',strtotime($this->request->data['Projeto']['dt_inicio']));
                    $projeto['Projeto']['dt_fim'] = date('Y-m-d',strtotime($this->request->data['Projeto']['dt_fim']));
                                        
                    if ($this->Projeto->save($projeto['Projeto'])) {
                                                
                        $arquivosController = new ArquivosController();
                        $arquivosController.editarArquivos($this->request->data['Arquivo'],$projeto);
                        
                        
                        $this->Session->setFlash(__('Projeto salvo com sucesso!'));
                            //return $this->redirect(array('action' => 'index'));
                    } else {
                            $this->Session->setFlash(__('O projeto não pode ser salvo. Por favor, tente novamente.'));
                    }
                        
		} else {
			$options = array('conditions' => array('Projeto.' . $this->Projeto->primaryKey => $id));
			$this->request->data = $this->Projeto->find('first', $options);
		}
//                $param = array('conditions'=>array('ProjetosArquivo.projeto_id'=> $id),
//                                                   'fields'=>array('Arquivo.id','Arquivo.a_nome','Arquivo.alias')
//                                                  );
//              
                
//                $param = array(
//                    'fields'=>array('a.*'),
//                    'joins'=>array(
//                        array(
//                            'table'=>'arquivos',
//                            'alias'=>'a',
//                            'type'=>'INNER',
//                            ''=>''
//                        )
//                    ),
//                );
                
                
		//$arquivos = $this->Projeto->Arquivo->ProjetosArquivo->find('list',$param);
                $arquivos = $this->getAllArquivosByProjetoId($id);
                //print_r($arquivos);
		$this->set(compact('arquivos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
            $this->layout = 'cpanel';   
		$this->Projeto->id = $id;
		if (!$this->Projeto->exists()) {
			throw new NotFoundException(__('Invalid projeto'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->Projeto->delete()) {
			$this->Session->setFlash(__('The projeto has been deleted.'));
		} else {
			$this->Session->setFlash(__('The projeto could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}
        
        public function getProjetoById($id)
        {
            if(!$this->Projeto->exists($id)){
                    throw new NotFoundException(__('Projeto inválido!'));
            }
            
            $paran = array('conditions'=>array('Projeto.id'=>$id),
                'recursivo'=>1,
                'callbacks'=>true
                );
            
            $projeto = $this->Projeto->find('first',$paran);
            return $projeto;            
        }
        
        public function createPathProjeto($uuidNamePath)
        {
            $filenome = WWW_ROOT . DS . 'files' . DS . 'projetos' . DS . $uuidNamePath;
            if(!file_exists($filenome))
            {
                return (mkdir($filenome, 0777))? true: false;                
            }
            return true;
        }
        
        public function verificaNomeProjeto()
        {            
            $this->layout = null;
            $projeto = null;
            if($this->request->is(array('post','put')))
            {
                $param = array('conditions'=>array('Projeto.nome_projeto'=>$this->request->data['nome_projeto']),
                    'recursivo'=>1,
                    'callbacks'=>true);

                $projeto = $this->Projeto->find('first',$param);                
//                if(!empty($projeto))
//                {
//                    return true;
//                }
            }
            //return false;
            //$this->Session->setFlash(_('Já existe um projeto com este nome!'));
            $this->set('projeto',$projeto);
        }
        
        public function getAllArquivosByProjetoId($idProjeto)
        {
            $sql="SELECT arq.* FROM multiweb.arquivos arq
                INNER JOIN multiweb.projetos_arquivos p_a ON (p_a.arquivo_id = arq.id)
                WHERE p_a.projeto_id = ".$idProjeto.";";
            
            $db = ConnectionManager::getDataSource('default');
            $statement = $db->rawQuery($sql);
            $statement->execute();
            $result = $statement->fetchAll(PDO::FETCH_ASSOC);
            
            return $result;            
        }
        
}
