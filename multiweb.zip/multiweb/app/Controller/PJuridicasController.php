<?php
App::uses('AppController', 'Controller');
/**
 * PJuridicas Controller
 *
 * @property PJuridica $PJuridica
 * @property PaginatorComponent $Paginator
 */
class PJuridicasController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->PJuridica->recursive = 0;
		$this->set('pJuridicas', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->PJuridica->exists($id)) {
			throw new NotFoundException(__('Invalid p juridica'));
		}
		$options = array('conditions' => array('PJuridica.' . $this->PJuridica->primaryKey => $id));
		$this->set('pJuridica', $this->PJuridica->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->PJuridica->create();
			if ($this->PJuridica->save($this->request->data)) {
				$this->Session->setFlash(__('The p juridica has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The p juridica could not be saved. Please, try again.'));
			}
		}
		$pessoas = $this->PJuridica->Pessoa->find('list');
		$this->set(compact('pessoas'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->PJuridica->exists($id)) {
			throw new NotFoundException(__('Invalid p juridica'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->PJuridica->save($this->request->data)) {
				$this->Session->setFlash(__('The p juridica has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The p juridica could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('PJuridica.' . $this->PJuridica->primaryKey => $id));
			$this->request->data = $this->PJuridica->find('first', $options);
		}
		$pessoas = $this->PJuridica->Pessoa->find('list');
		$this->set(compact('pessoas'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->PJuridica->id = $id;
		if (!$this->PJuridica->exists()) {
			throw new NotFoundException(__('Invalid p juridica'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->PJuridica->delete()) {
			$this->Session->setFlash(__('The p juridica has been deleted.'));
		} else {
			$this->Session->setFlash(__('The p juridica could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}}
