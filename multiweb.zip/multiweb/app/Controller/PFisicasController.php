<?php
App::uses('AppController', 'Controller');
/**
 * PFisicas Controller
 *
 * @property PFisica $PFisica
 * @property PaginatorComponent $Paginator
 */
class PFisicasController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->PFisica->recursive = 0;
		$this->set('pFisicas', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->PFisica->exists($id)) {
			throw new NotFoundException(__('Invalid p fisica'));
		}
		$options = array('conditions' => array('PFisica.' . $this->PFisica->primaryKey => $id));
		$this->set('pFisica', $this->PFisica->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->PFisica->create();
			if ($this->PFisica->save($this->request->data)) {
				$this->Session->setFlash(__('The p fisica has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The p fisica could not be saved. Please, try again.'));
			}
		}
		$pessoas = $this->PFisica->Pessoa->find('list');
		$this->set(compact('pessoas'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->PFisica->exists($id)) {
			throw new NotFoundException(__('Invalid p fisica'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->PFisica->save($this->request->data)) {
				$this->Session->setFlash(__('The p fisica has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The p fisica could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('PFisica.' . $this->PFisica->primaryKey => $id));
			$this->request->data = $this->PFisica->find('first', $options);
		}
		$pessoas = $this->PFisica->Pessoa->find('list');
		$this->set(compact('pessoas'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->PFisica->id = $id;
		if (!$this->PFisica->exists()) {
			throw new NotFoundException(__('Invalid p fisica'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->PFisica->delete()) {
			$this->Session->setFlash(__('The p fisica has been deleted.'));
		} else {
			$this->Session->setFlash(__('The p fisica could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}}
