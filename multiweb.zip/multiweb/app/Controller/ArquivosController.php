<?php
App::uses('AppController', 'Controller');
/**
 * Arquivos Controller
 *
 * @property Arquivo $Arquivo
 * @property PaginatorComponent $Paginator
 */
class ArquivosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Arquivo->recursive = 0;
		$this->set('arquivos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Arquivo->exists($id)) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		$options = array('conditions' => array('Arquivo.' . $this->Arquivo->primaryKey => $id));
		$this->set('arquivo', $this->Arquivo->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Arquivo->create();
			if ($this->Arquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The arquivo could not be saved. Please, try again.'));
			}
		}
		$projetos = $this->Arquivo->Projeto->find('list');
		$this->set(compact('projetos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Arquivo->exists($id)) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Arquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The arquivo could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Arquivo.' . $this->Arquivo->primaryKey => $id));
			$this->request->data = $this->Arquivo->find('first', $options);
		}
		$projetos = $this->Arquivo->Projeto->find('list');
		$this->set(compact('projetos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
		$this->Arquivo->id = $id;
		if (!$this->Arquivo->exists()) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->Arquivo->delete()) {
			$this->Session->setFlash(__('The arquivo has been deleted.'));
		} else {
			$this->Session->setFlash(__('The arquivo could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'index'));
	}}
