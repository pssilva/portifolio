<?php
App::uses('AppController', 'Controller');
App::import('Controller','ProjetosArquivos');
/**
 * Arquivos Controller
 *
 * @property Arquivo $Arquivo
 * @property PaginatorComponent $Paginator
 */
class ArquivosController extends AppController {

/**
 * Components
 *
 * @var array
 */
	public $components = array('Paginator');

/**
 * index method
 *
 * @return void
 */
	public function index() {
		$this->Arquivo->recursive = 0;
		$this->set('arquivos', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->Arquivo->exists($id)) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		$options = array('conditions' => array('Arquivo.' . $this->Arquivo->primaryKey => $id));
		$this->set('arquivo', $this->Arquivo->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
	public function add() {
		if ($this->request->is('post')) {
			$this->Arquivo->create();
			if ($this->Arquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The arquivo could not be saved. Please, try again.'));
			}
		}
		$projetos = $this->Arquivo->Projeto->find('list');
		$this->set(compact('projetos'));
	}

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
		if (!$this->Arquivo->exists($id)) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		if ($this->request->is(array('post', 'put'))) {
			if ($this->Arquivo->save($this->request->data)) {
				$this->Session->setFlash(__('The arquivo has been saved.'));
				return $this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The arquivo could not be saved. Please, try again.'));
			}
		} else {
			$options = array('conditions' => array('Arquivo.' . $this->Arquivo->primaryKey => $id));
			$this->request->data = $this->Arquivo->find('first', $options);
		}
		$projetos = $this->Arquivo->Projeto->find('list');
		$this->set(compact('projetos'));
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
            $this->layout=null;
		$this->Arquivo->id = $id;
//                echo "ffffffffff id = " . $id;
//                 exit;
		if (!$this->Arquivo->exists()) {
			throw new NotFoundException(__('Invalid arquivo'));
		}
		$this->request->onlyAllow('post', 'delete');
		if ($this->Arquivo->delete()) {
			$this->Session->setFlash(__('Arquivo deletado com sucesso!.'));
                        
		} else {
			$this->Session->setFlash(__('Aqruivo não pode ser deletado. Por favor, tente novamente!'));
                        $id = 0;
		}
		//return $id;//$this->redirect(array('action' => 'index'));
                $this->set(compact('id'));
	}
        
        public function salvarArquivos($arrayArquivos,$objProjeto)
        {   
            $projetosArquivosController = new ProjetosArquivosController();
            $arq = array();
            if(isset($arrayArquivos['a_nome']) && !empty($arrayArquivos['a_nome']))
            {
                
                
                for($i=0;$i<count($arrayArquivos['a_nome']);$i++)
                {
                    if(!isset($arrayArquivos['id'][$i]))
                    {
                        $uuid = $this->generateUuid();                    
                        $arrayArquivos['arquivo'][$i] = $this->salvaFileInPath($arrayArquivos['arquivo'][$i],$objProjeto,$uuid['uuid']);

                        $arq['Arquivo']['uuid'] = $uuid['uuid'];
                        $arq['Arquivo']['alias'] = $arrayArquivos['alias'][$i];
                        $arq['Arquivo']['words_key'] = $arrayArquivos['words_key'][$i] . ";" . $arrayArquivos['arquivo'][$i]['name'];
                        $arq['Arquivo']['local'] = $arrayArquivos['arquivo'][$i]['tmp_name'];
                        $arq['Arquivo']['a_nome'] = $arrayArquivos['arquivo'][$i]['name'];
                        $arq['Arquivo']['a_descricao'] = $arrayArquivos['a_descricao'][$i];
                        $arq['Arquivo']['a_hash'] = md5_file(WWW_ROOT . $arrayArquivos['arquivo'][$i]['tmp_name'] . DS . $uuid['uuid']);
                        $arq['Arquivo']['a_type'] = $arrayArquivos['arquivo'][$i]['type'];
                        $arq['Arquivo']['userId'] = $arrayArquivos['userId'][$i];
                        $arq['Arquivo']['modifiedByUserId'] = $arrayArquivos['modifiedByUserId'][$i];

                        $idArquivo = $this->salvar($arq);
                        $projetosArquivosController->salvar($idArquivo,$objProjeto['Projeto']['id']);
                    }
                }
            }
            return $arq;
        }
        
        public function editarArquivos($newArquivos,$objProjeto){
            $arq = array();
            
                 for($i=0;$i<count($newArquivos['a_nome']);$i++){
                     
                    
                     
                     $arq['Arquivo']['alias'] = $newArquivos['alias'][$i];
                     $arq['Arquivo']['words_key'] = $newArquivos['words_key'][$i];
                     $arq['Arquivo']['a_descricao'] = $newArquivos['a_descricao'][$i];
                     $arq['Arquivo']['modifiedByUserId'] = $newArquivos['modifiedByUserId'][$i];
                     
                   
                   
                   if(isset($newArquivos['id'][$i]) && !empty($newArquivos['id'][$i]))
                    {
                       
                        if(isset($newArquivos['arquivo'][$i]['name']) && !empty($newArquivos['arquivo'][$i]['name'])){
                            $newArquivos['arquivo'][$i] = $this->salvaFileInPath($newArquivos['arquivo'][$i],$objProjeto,$newArquivos['uuid'][$i]);

                            $arq['Arquivo']['local'] = $newArquivos['arquivo'][$i]['tmp_name'];
                            $arq['Arquivo']['a_nome'] = $newArquivos['arquivo'][$i]['name'];
                            $arq['Arquivo']['a_type'] = $newArquivos['arquivo'][$i]['type'];
                            $arq['Arquivo']['a_hash'] = md5_file(WWW_ROOT . $newArquivos['arquivo'][$i]['tmp_name'] . DS . $newArquivos['uuid'][$i]);
                        
                        } else{
                            $oldArquivo = $this->getArquivoById($newArquivos['id'][$i]);

                            $arq['Arquivo']['local'] = $oldArquivo['Arquivo']['local'];
                            $arq['Arquivo']['a_nome'] = $oldArquivo['Arquivo']['a_nome'];
                            $arq['Arquivo']['a_type'] = $oldArquivo['Arquivo']['a_type'];
                            $arq['Arquivo']['a_hash'] = $oldArquivo['Arquivo']['a_hash'];

                           $arq['Arquivo']['id'] = $newArquivos['id'][$i];
                           $arq['Arquivo']['uuid'] = $newArquivos['uuid'][$i];
                       }
                       
                       $this->editar($arq);
                    }
                   else
                    {
                       $this->salvarArquivos($arq,$objProjeto);
                       
                    }                  
                 }
           $this->salvarArquivos($newArquivos, $objProjeto);
        }

        public function salvaFileInPath($arquivos,$objProjeto,$uuidNameFile)
        {
            $pathProjeto = WWW_ROOT . DS . 'files' . DS . 'projetos' . DS . $objProjeto['Projeto']['uuid'];
            $filename = $pathProjeto . DS . $uuidNameFile;
            
            $this->createPath($pathProjeto);
                            
              if(!empty($arquivos['tmp_name']) && is_uploaded_file($arquivos['tmp_name']))
                {
                   if(move_uploaded_file($arquivos['tmp_name'],$filename))
                   {
                       $arquivos['tmp_name'] = DS . 'files' . DS . 'projetos' . DS . $objProjeto['Projeto']['uuid'];
                   }
                }
            return $arquivos;
        }
        
        
        public function editar($arquivo){    
            $id = 0;
            if(!$this->Arquivo->exists($arquivo['Arquivo']['id'])){
                throw new NotFoundException(__('Arquivo inválido!'));
            }
            
            if($this->Arquivo->save($arquivo['Arquivo'])){
                $id =  $this->Arquivo->id;
            }
            
           return $id;
        }
        
        public function salvar($arquivo) {            
                if (!empty($arquivo)) {
                        $this->Arquivo->create();
                        if ($this->Arquivo->save($arquivo['Arquivo'])) {         
                            return $this->Arquivo->id;
                        } else {
                            return 0;
                        }
                }
            return 0;
        }
        
      public function getArquivoById($id)
        {
          if(!$this->Arquivo->exists($id)){
              throw new NotFoundException(__('Arquivo inválido!'));
          }          
          $paran = array('conditions'=>array('Arquivo.id'=>$id),
              'recursivo'=>0,
              'callbacks'=>true);
          
          $arquivo = $this->Arquivo->find('first',$paran);
          return $arquivo;          
        }
}
